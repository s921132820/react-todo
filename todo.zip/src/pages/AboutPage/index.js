function AboutPage() {
  return(
  <div>
    <h1>About</h1>
    <p>writer: sehee</p>
    <p>Email: s921132820@gmail.com</p>
  </div>
  )
}

export default AboutPage;